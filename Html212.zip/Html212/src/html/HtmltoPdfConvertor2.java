package html;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.parser.Parser;
import org.w3c.dom.DocumentBuilderFactory;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class HtmltoPdfConvertor2 {
    public static void main(String[] args) {
        String htmlFilePath = "C://Users//User//Downloads//test.html";

        try {
            Document jsoupDoc = Jsoup.parse(new File(htmlFilePath), "UTF-8", "", Parser.xmlParser());

            // Convert Jsoup Document to W3C DOM Document
            org.w3c.dom.Document w3cDoc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            org.jsoup.helper.W3CDom.convert(jsoupDoc, w3cDoc);

            String baseUri = new File(htmlFilePath).getParentFile().toURI().toString();

            String outputFilePath = "C://Users//User//Downloads//ppp.pdf";
            FileOutputStream os = new FileOutputStream(outputFilePath);
            ITextRenderer renderer = new ITextRenderer();

            // Set base URI for resolving relative paths
            renderer.setDocument(w3cDoc, baseUri);

            renderer.layout();
            renderer.createPDF(os, true);
            os.close();

            System.out.println("PDF file generated at: " + outputFilePath);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Error: Unable to load or parse the HTML file.");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error: An unexpected error occurred during PDF conversion.");
        }
    }
}
